from django.db import models

class Tenants(models.Model):
    TenantID = models.IntegerField(primary_key=True)
    TenantName = models.CharField(max_length=100)
    TenantEmail = models.EmailField()
    TenantPhone = models.CharField(max_length=20)
    TenantAddress = models.CharField(max_length=200)
    TenantMoveInDate = models.DateField()
    TenantMoveOutDate = models.DateField(null=True, blank=True)
    TenantStatus = models.CharField(max_length=20)

    def __str__(self):
        return self.TenantName

class Properties(models.Model):
    PropertyID = models.IntegerField(primary_key=True)
    PropertyAddress = models.CharField(max_length=200)
    PropertyType = models.CharField(max_length=50)
    NumberOfUnits = models.IntegerField()
    PropertyManager = models.CharField(max_length=100)

    def __str__(self):
        return self.PropertyAddress

class Billing(models.Model):
    BillingID = models.IntegerField(primary_key=True)
    Tenant = models.ForeignKey(Tenants, on_delete=models.CASCADE)
    Property = models.ForeignKey(Properties, on_delete=models.CASCADE)
    BillingPeriod = models.CharField(max_length=20)
    BillingAmount = models.DecimalField(max_digits=10, decimal_places=2)
    DueDate = models.DateField()
    PaymentDate = models.DateField(null=True, blank=True)
    PaymentMethod = models.CharField(max_length=50)
    PaymentStatus = models.CharField(max_length=20)

    def __str__(self):
        return f"Billing ID: {self.BillingID}"

class Notices(models.Model):
    NoticeID = models.IntegerField(primary_key=True)
    Tenant = models.ForeignKey(Tenants, on_delete=models.CASCADE)
    Property = models.ForeignKey(Properties, on_delete=models.CASCADE)
    NoticeType = models.CharField(max_length=100)
    NoticeDate = models.DateField()
    NoticeDeliveryMethod = models.CharField(max_length=50)
    NoticeStatus = models.CharField(max_length=20)

    def __str__(self):
        return f"Notice ID: {self.NoticeID}"

class Payments(models.Model):
    PaymentID = models.IntegerField(primary_key=True)
    Billing = models.ForeignKey(Billing, on_delete=models.CASCADE)
    PaymentAmount = models.DecimalField(max_digits=10, decimal_places=2)
    PaymentDate = models.DateField()
    PaymentMethod = models.CharField(max_length=50)
    PaymentStatus = models.CharField(max_length=20)

    def __str__(self):
        return f"Payment ID: {self.PaymentID}"

class WorkOrders(models.Model):
    WorkOrderID = models.IntegerField(primary_key=True)
    Property = models.ForeignKey(Properties, on_delete=models.CASCADE)
    Tenant = models.ForeignKey(Tenants, on_delete=models.CASCADE)
    WorkOrderType = models.CharField(max_length=50)
    WorkOrderDescription = models.TextField()
    WorkOrderStatus = models.CharField(max_length=20)
    WorkOrderPriority = models.CharField(max_length=20)
    WorkOrderAssignedTo = models.CharField(max_length=100)
    WorkOrderCompletionDate = models.DateField()

    def __str__(self):
        return f"Work Order ID: {self.WorkOrderID}"

class Users(models.Model):
    UserID = models.IntegerField(primary_key=True)
    Username = models.CharField(max_length=50)
    Password = models.CharField(max_length=100)
    UserRole = models.CharField(max_length=50)
    Permissions = models.CharField(max_length=100)

    def __str__(self):
        return self.Username

